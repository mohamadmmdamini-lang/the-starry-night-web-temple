# Pixel Perfect Picture

A React, TypeScript, and TanStack Start web application.

## Requirements

- Node.js LTS
- npm

## Run locally

```bash
npm install
npm run dev
```

Open the local URL printed by Vite in your browser.

## Production build

```bash
npm run build
npm run preview
```

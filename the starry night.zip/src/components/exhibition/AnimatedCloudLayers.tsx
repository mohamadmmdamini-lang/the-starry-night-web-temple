import { useRef } from "react";
import { gsap, useGSAP, MOTION } from "@/lib/gsap";
import { ART } from "./art";

/**
 * Three painted cloud layers. Each layer has an outer wrapper (scroll parallax, driven by
 * CloudScene) and an inner wrapper that drifts continuously like wind through the painting.
 */
export function AnimatedCloudLayers() {
  const root = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      const mm = gsap.matchMedia();
      mm.add(MOTION, () => {
        const drift = (sel: string, amp: number, dur: number, rot: number) => {
          const el = root.current?.querySelector(sel);
          if (!el) return;
          // Two unsynchronised sine motions on different axes avoid a mechanical loop.
          gsap.to(el, {
            xPercent: `random(${-amp}, ${amp})`,
            duration: `random(${dur}, ${dur * 1.6})`,
            ease: "sine.inOut",
            repeat: -1,
            yoyo: true,
            repeatRefresh: true,
          });
          gsap.to(el, {
            yPercent: `random(${-amp / 2}, ${amp / 2})`,
            rotation: `random(${-rot}, ${rot})`,
            duration: `random(${dur * 0.8}, ${dur * 1.3})`,
            ease: "sine.inOut",
            repeat: -1,
            yoyo: true,
            repeatRefresh: true,
          });
        };
        drift(".cloud-layer--far .cloud-drift", 1.5, 26, 0.6);
        drift(".cloud-layer--mid .cloud-drift", 4, 15, 1.4);
        drift(".cloud-layer--front .cloud-drift", 3, 10, 0.8);
      });
      return () => mm.revert();
    },
    { scope: root },
  );

  return (
    <div ref={root} className="absolute inset-0">
      <div className="cloud-layer cloud-layer--far">
        <div className="cloud-drift">
          <img src={ART.sky.src} width={ART.sky.w} height={ART.sky.h} alt="" loading="lazy" decoding="async" />
        </div>
      </div>
      <div className="cloud-layer cloud-layer--mid">
        <div className="cloud-drift">
          <img src={ART.cloudsMid.src} width={ART.cloudsMid.w} height={ART.cloudsMid.h} alt="" loading="lazy" decoding="async" />
        </div>
      </div>
      <div className="cloud-layer cloud-layer--front">
        <div className="cloud-drift">
          <img src={ART.cloudsFront.src} width={ART.cloudsFront.w} height={ART.cloudsFront.h} alt="" loading="lazy" decoding="async" />
        </div>
      </div>
      <div className="stage-vignette" />
    </div>
  );
}

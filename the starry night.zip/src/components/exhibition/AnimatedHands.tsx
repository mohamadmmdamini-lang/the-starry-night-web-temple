import type { CSSProperties, Ref } from "react";
import { HANDS } from "./art";

interface HandProps {
  side: "left" | "right";
  outerRef?: Ref<HTMLDivElement>;
  innerRef?: Ref<HTMLDivElement>;
}

/**
 * A transparent arm cut-out anchored at its index fingertip: the element's (0,0) point
 * is the fingertip, so animating x/y moves the fingertip precisely.
 */
export function Hand({ side, outerRef, innerRef }: HandProps) {
  const h = HANDS[side];
  const style = { "--nw": h.w, "--tx": h.tipX, "--ty": h.tipY } as CSSProperties;
  return (
    <div ref={outerRef} className={`hand hand--${side}`} aria-hidden="true">
      <div ref={innerRef} className="hand__inner">
        <img
          className="hand__img"
          src={h.src}
          width={h.w}
          height={h.h}
          alt=""
          draggable={false}
          decoding="async"
          style={style}
        />
      </div>
    </div>
  );
}

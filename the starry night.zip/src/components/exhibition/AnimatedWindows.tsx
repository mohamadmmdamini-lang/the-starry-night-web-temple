import { useRef } from "react";
import { gsap, useGSAP, MOTION } from "@/lib/gsap";
import { VILLAGE_WINDOWS } from "./windows-data";

/**
 * Glow overlays for every lit window in the village painting. Each window runs its own
 * randomised cycle (illuminate, glow, dim, off, return) so nothing blinks in sync.
 */
export function AnimatedWindows() {
  const root = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      const mm = gsap.matchMedia();
      mm.add(MOTION, () => {
        root.current?.querySelectorAll<HTMLElement>(".window-light").forEach((win) => {
          const glow = win.querySelector(".window-light__glow");
          const shade = win.querySelector(".window-light__shade");
          const tl = gsap.timeline({
            repeat: -1,
            repeatRefresh: true,
            delay: gsap.utils.random(0, 6),
          });
          tl.to(glow, { opacity: "random(0.75, 1)", duration: "random(1.2, 3.5)", ease: "sine.inOut" })
            .to(glow, { opacity: "random(0.45, 0.7)", duration: "random(2, 5)", ease: "sine.inOut" }, "+=random(2, 7)")
            .to(glow, { opacity: "random(0.8, 1)", duration: "random(1, 3)", ease: "sine.inOut" })
            .to(glow, { opacity: 0, duration: "random(1.5, 4)", ease: "power1.in" }, "+=random(3, 10)")
            .to(shade, { opacity: "random(0.55, 0.85)", duration: "random(1.5, 3)", ease: "power1.inOut" }, "<")
            .to(shade, { opacity: 0, duration: "random(1, 2.5)", ease: "power1.inOut" }, "+=random(2, 9)")
            .to(glow, { opacity: "random(0.35, 0.6)", duration: "random(1.5, 3)", ease: "sine.inOut" }, "<0.4");
        });
      });
      return () => mm.revert();
    },
    { scope: root },
  );

  return (
    <div ref={root} className="absolute inset-0">
      {VILLAGE_WINDOWS.map(([x, y, w, h], i) => (
        <span
          key={i}
          className="window-light"
          style={{ left: `${x}%`, top: `${y}%`, width: `${w * 1.15}%`, height: `${h * 1.1}%` }}
        >
          <span className="window-light__shade" />
          <span className="window-light__glow" />
        </span>
      ))}
    </div>
  );
}

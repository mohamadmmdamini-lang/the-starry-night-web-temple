import { useRef } from "react";
import type { SiteContent } from "@/content/site";
import { gsap, useGSAP, MOTION, REDUCED } from "@/lib/gsap";
import { GlassInformationPanel } from "./GlassInformationPanel";
import { revealPanels } from "./reveal";
import { useStage } from "./StageContext";

/** Chapter 03 — the breathing sky: layered cloud parallax and the personal introduction. */
export function CloudScene({ content }: { content: SiteContent }) {
  const root = useRef<HTMLElement>(null);
  const stage = useStage();
  const c = content.clouds;

  useGSAP(
    () => {
      const mm = gsap.matchMedia();
      mm.add(MOTION, () => {
        const layers = stage.clouds.current;
        if (!layers) return;
        const st = { trigger: root.current, start: "top bottom", end: "bottom top", scrub: 1.8, invalidateOnRefresh: true };
        gsap.fromTo(layers.querySelector(".cloud-layer--far"), { yPercent: 0, xPercent: 0, scale: 1 }, { yPercent: -6, xPercent: -1.5, scale: 1.025, ease: "none", scrollTrigger: st });
        gsap.fromTo(layers.querySelector(".cloud-layer--mid"), { yPercent: 4, xPercent: -2, scale: 1.02 }, { yPercent: -12, xPercent: 4, scale: 1.06, ease: "none", scrollTrigger: st });
        gsap.fromTo(layers.querySelector(".cloud-layer--front"), { yPercent: 8, xPercent: 3, scale: 1.04 }, { yPercent: -19, xPercent: -5, scale: 1.11, ease: "none", scrollTrigger: st });
        if (root.current) revealPanels(root.current);
      });
      mm.add(REDUCED, () => {
        gsap.set(stage.opening.current, { autoAlpha: 1 });
        gsap.set(stage.clouds.current, { autoAlpha: 0 });
        gsap.to(stage.clouds.current, {
          autoAlpha: 1,
          duration: 0.6,
          scrollTrigger: { trigger: root.current, start: "top 60%", toggleActions: "play none none reverse" },
        });
      });
      return () => mm.revert();
    },
    { scope: root },
  );

  return (
    <section id="chapter-sky" ref={root} className="scene" aria-labelledby="sky-title" dir={content.dir}>
      <header className="scene__intro" data-intro>
        <p className="label-caps text-turquoise">{c.chapter}</p>
        <h2 id="sky-title" className="font-display mt-4 text-5xl font-light text-ivory md:text-7xl">
          {c.title}
        </h2>
        <p className="font-display mx-auto mt-5 max-w-xl text-xl text-muted-foreground italic">{c.lede}</p>
      </header>

      <div className="panel-row" data-align="start">
        <GlassInformationPanel id="p-about" {...c.about}>
          <p data-reveal className="mt-6 text-base leading-relaxed text-muted-foreground md:text-lg">
            {c.about.body}
          </p>
        </GlassInformationPanel>
      </div>

      <div className="panel-row" data-align="end">
        <GlassInformationPanel id="p-story" {...c.story}>
          <p data-reveal className="mt-6 text-base leading-relaxed text-muted-foreground md:text-lg">
            {c.story.body}
          </p>
        </GlassInformationPanel>
      </div>

      <div className="panel-row" data-align="start">
        <GlassInformationPanel id="p-philosophy" {...c.philosophy}>
          <p data-reveal className="mt-6 text-base leading-relaxed text-muted-foreground md:text-lg">
            {c.philosophy.body}
          </p>
          <blockquote
            data-reveal
            className="font-display mt-8 border-s border-gold/40 ps-5 text-2xl text-gold-glow italic"
          >
            “{c.philosophy.quote}”
          </blockquote>
        </GlassInformationPanel>
      </div>

      <div className="panel-row" data-align="end">
        <GlassInformationPanel id="p-skills" {...c.skills}>
          <p data-reveal className="mt-6 text-base leading-relaxed text-muted-foreground">{c.skills.body}</p>
          <ul className="mt-6 divide-y divide-border">
            {c.skills.items.map((s, i) => (
              <li key={i} data-reveal className="flex items-baseline gap-5 py-4">
                <span className="font-display w-6 text-lg text-gold italic">{["i", "ii", "iii", "iv"][i]}</span>
                <span className="flex-1">
                  <span className="font-display block text-xl text-ivory">{s.name}</span>
                  <span className="block text-sm text-muted-foreground">{s.note}</span>
                </span>
              </li>
            ))}
          </ul>
        </GlassInformationPanel>
      </div>
    </section>
  );
}

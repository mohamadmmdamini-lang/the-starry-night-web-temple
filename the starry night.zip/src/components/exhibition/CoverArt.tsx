import type { CSSProperties, ReactNode } from "react";

interface CoverArtProps {
  src: string;
  width: number;
  height: number;
  /** Focal point 0–1 used when the artwork is cropped. */
  focusX?: number;
  focusY?: number;
  alt?: string;
  priority?: boolean;
  children?: ReactNode;
}

/**
 * Covers its parent like object-fit: cover while exposing a box with the artwork's exact
 * aspect ratio, so overlays (moon, windows) can be positioned in artwork percentages.
 */
export function CoverArt({
  src,
  width,
  height,
  focusX = 0.5,
  focusY = 0.5,
  alt = "",
  priority = false,
  children,
}: CoverArtProps) {
  const style = { "--ar": width / height, "--fx": focusX, "--fy": focusY } as CSSProperties;
  return (
    <div className="cover-host">
      <div className="cover-art" style={style}>
        <img
          src={src}
          width={width}
          height={height}
          alt={alt}
          loading={priority ? "eager" : "lazy"}
          decoding="async"
          fetchPriority={priority ? "high" : "auto"}
        />
        {children}
      </div>
    </div>
  );
}

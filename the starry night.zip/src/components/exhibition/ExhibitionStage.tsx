import { useIsMobile } from "@/hooks/use-mobile";
import { ART } from "./art";
import { AnimatedCloudLayers } from "./AnimatedCloudLayers";
import { AnimatedWindows } from "./AnimatedWindows";
import { CoverArt } from "./CoverArt";
import { StarryNightArtwork } from "./StarryNightArtwork";
import { useStage } from "./StageContext";

/**
 * The fixed painted world behind all content. Each layer has an outer element (faded in by
 * the scene that arrives) and an inner element (faded out by the scene that follows), so no
 * two ScrollTriggers ever animate the same property.
 */
export function ExhibitionStage() {
  const s = useStage();
  const isMobile = useIsMobile();
  return (
    <div className="stage" aria-hidden="true">
      <div className="stage-layer">
        <StarryNightArtwork frameRef={s.opening} flashRef={s.openingFlash} priority />
      </div>

      <div ref={s.clouds} className="stage-layer" data-hidden>
        <div ref={s.cloudsInner} className="stage-layer__inner">
          <AnimatedCloudLayers />
        </div>
      </div>

      <div ref={s.village} className="stage-layer" data-hidden>
        <div ref={s.villageInner} className="stage-layer__inner village-art">
          <CoverArt
            src={ART.village.src}
            width={ART.village.w}
            height={ART.village.h}
            focusX={isMobile ? 0.62 : 0.5}
            focusY={0.6}
          >
            <AnimatedWindows />
          </CoverArt>
          <div className="stage-vignette" />
        </div>
      </div>

      <div ref={s.finale} className="stage-layer" data-hidden>
        <StarryNightArtwork />
      </div>
    </div>
  );
}

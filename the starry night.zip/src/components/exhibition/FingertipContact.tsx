import { gsap } from "@/lib/gsap";

const SPARKS = 28;

/** Glow, light wave and golden sparks that live at the fingertip contact point. */
export function FingertipContact() {
  return (
    <>
      <span className="contact-glow" />
      <span className="contact-ring" />
      <span className="contact-flash" />
      {Array.from({ length: SPARKS }, (_, i) => (
        <span key={i} className="spark" />
      ))}
    </>
  );
}

/** Time-based energy pulse fired at the exact contact frame. */
export function fireContactBurst(scope: Element, flash?: Element | null) {
  const sparks = scope.querySelectorAll<HTMLElement>(".spark");
  const burst = scope.querySelector(".contact-flash");
  const tl = gsap.timeline();
  tl.fromTo(
    burst,
    { scale: 0.2, autoAlpha: 1 },
    { scale: 1.8, autoAlpha: 0, duration: 1.1, ease: "expo.out" },
    0,
  );
  if (flash) {
    tl.fromTo(flash, { opacity: 0.9 }, { opacity: 0, duration: 1.4, ease: "power2.out" }, 0);
  }
  sparks.forEach((el) => {
    const angle = Math.random() * Math.PI * 2;
    const dist = gsap.utils.random(40, 170);
    tl.fromTo(
      el,
      { x: 0, y: 0, scale: gsap.utils.random(0.6, 1.6), autoAlpha: 1 },
      {
        x: Math.cos(angle) * dist,
        y: Math.sin(angle) * dist - gsap.utils.random(0, 40),
        scale: 0.1,
        autoAlpha: 0,
        duration: gsap.utils.random(1.1, 2.2),
        ease: "expo.out",
      },
      gsap.utils.random(0, 0.08),
    );
  });
  return tl;
}

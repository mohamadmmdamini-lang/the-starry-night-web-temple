import type { PointerEvent, ReactNode } from "react";
import { cn } from "@/lib/utils";

interface Props {
  index: string;
  label: string;
  heading: string;
  id: string;
  wide?: boolean;
  children?: ReactNode;
}

/** Translucent glass floating above the painting, with a cursor-following sheen. */
export function GlassInformationPanel({ index, label, heading, id, wide, children }: Props) {
  const onMove = (e: PointerEvent<HTMLElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    e.currentTarget.style.setProperty("--mx", `${e.clientX - r.left}px`);
    e.currentTarget.style.setProperty("--my", `${e.clientY - r.top}px`);
  };
  return (
    <article
      className={cn("glass-panel", wide && "glass-panel--wide")}
      aria-labelledby={id}
      onPointerMove={onMove}
    >
      <span className="glass-panel__edge" aria-hidden="true" />
      <div className="relative">
        <p data-reveal className="label-caps flex items-center gap-4 text-gold">
          <span className="font-display text-base tracking-normal text-gold-glow">{index}</span>
          <span className="hairline w-10" aria-hidden="true" />
          <span>{label}</span>
        </p>
        <h3
          id={id}
          data-reveal
          className="font-display mt-5 text-3xl leading-[1.08] font-light text-ivory md:text-[2.6rem]"
        >
          {heading}
        </h3>
        {children}
      </div>
    </article>
  );
}

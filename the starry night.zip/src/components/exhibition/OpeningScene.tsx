import { useRef } from "react";
import type { SiteContent } from "@/content/site";
import { gsap, useGSAP, MOTION, REDUCED, MOBILE } from "@/lib/gsap";
import { Hand } from "./AnimatedHands";
import { FingertipContact, fireContactBurst } from "./FingertipContact";
import { useStage } from "./StageContext";

/**
 * Chapters 01–02. Pinned, scroll-scrubbed timeline: the arms enter, approach, hesitate,
 * touch — the contact frame fires a golden pulse — then the camera dives into the sky.
 */
export function OpeningScene({ content }: { content: SiteContent }) {
  const root = useRef<HTMLElement>(null);
  const point = useRef<HTMLDivElement>(null);
  const left = useRef<HTMLDivElement>(null);
  const right = useRef<HTMLDivElement>(null);
  const stage = useStage();
  const c = content.opening;

  useGSAP(
    () => {
      const mm = gsap.matchMedia();

      mm.add({ motion: MOTION, mobile: MOBILE }, (ctx) => {
        const { mobile } = ctx.conditions as { mobile: boolean };
        const q = gsap.utils.selector(root);
        const start = mobile ? 70 : 62;
        const near = mobile ? 2.4 : 1.6;

        const tl = gsap.timeline({
          defaults: { ease: "none" },
          scrollTrigger: {
            trigger: root.current,
            start: "top top",
            end: mobile ? "+=420%" : "+=520%",
            pin: true,
            scrub: 1.6,
            anticipatePin: 1.5,
          },
        });

        // A. Start outside the interaction area; painting slowly settles.
        tl.fromTo(left.current, { x: `${-start}vw` }, { x: `${-start}vw`, duration: 0.01 }, 0)
          .fromTo(right.current, { x: `${start}vw` }, { x: `${start}vw`, duration: 0.01 }, 0)
          .fromTo(stage.opening.current, { scale: 1.08 }, { scale: 1, duration: 2.4, ease: "power1.out" }, 0)
          .to(q(".opening__title > *"), { y: -40, autoAlpha: 0, filter: "blur(8px)", stagger: 0.08, duration: 1 }, 0.3)
          // B. Left arm enters.
          .to(left.current, { x: "-24vw", duration: 1.3, ease: "power2.out" }, 0.3)
          // C. Right arm enters.
          .to(right.current, { x: "24vw", duration: 1.3, ease: "power2.out" }, 0.8)
          // D. Both approach slowly.
          .to(left.current, { x: "-5vw", duration: 1, ease: "sine.inOut" }, 2.1)
          .to(right.current, { x: "5vw", duration: 1, ease: "sine.inOut" }, 2.1)
          // E. Fingertips come extremely close; light gathers.
          .to(left.current, { x: `${-near}vw`, duration: 0.7, ease: "power1.out" }, 3.1)
          .to(right.current, { x: `${near}vw`, duration: 0.7, ease: "power1.out" }, 3.1)
          .fromTo(q(".contact-glow"), { autoAlpha: 0, scale: 0.3 }, { autoAlpha: 0.55, scale: 0.7, duration: 1.2 }, 3.0)
          // F. Pause — anticipation (a barely-there tremor).
          .to(left.current, { y: -2, duration: 0.25, ease: "sine.inOut", yoyo: true, repeat: 1 }, 3.8)
          // G. Precise contact.
          .to([left.current, right.current], { x: 0, y: 0, duration: 0.18, ease: "power2.in" }, 4.3)
          .addLabel("contact", 4.48)
          // H–J. Golden pulse and expanding wave of light.
          .fromTo(q(".contact-glow"), { scale: 0.7 }, { autoAlpha: 1, scale: 1.25, duration: 0.25 }, "contact")
          .fromTo(q(".contact-ring"), { scale: 0.15, autoAlpha: 0.95 }, { scale: 7, autoAlpha: 0, duration: 1.1, ease: "power1.out" }, "contact")
          .to(q(".contact-glow"), { autoAlpha: 0.45, scale: 1, duration: 0.6 }, "contact+=0.3")
          .fromTo(q(".opening__quote"), { autoAlpha: 0, y: 30 }, { autoAlpha: 1, y: 0, duration: 0.6 }, "contact+=0.35")
          .fromTo(q(".opening__quote p"), { filter: "blur(8px)" }, { filter: "blur(0px)", stagger: 0.25, duration: 0.6 }, "contact+=0.35")
          // K. The next painting emerges: dive into the sky.
          .to(q(".opening__quote"), { autoAlpha: 0, y: -30, duration: 0.5 }, "contact+=1.6")
          .to(left.current, { x: "-40vw", autoAlpha: 0, duration: 1.1, ease: "power2.in" }, "contact+=1.7")
          .to(right.current, { x: "40vw", autoAlpha: 0, duration: 1.1, ease: "power2.in" }, "contact+=1.7")
          .to(q(".contact-glow"), { autoAlpha: 0, scale: 3, duration: 1 }, "contact+=1.7")
          .to(stage.opening.current, { scale: 2.6, filter: "blur(10px)", autoAlpha: 0, duration: 1.4, ease: "power2.in" }, "contact+=1.8")
          .fromTo(stage.clouds.current, { autoAlpha: 0, scale: 1.25 }, { autoAlpha: 1, scale: 1, duration: 1.4, ease: "power1.out" }, "contact+=2.2");

        // The exact contact frame fires a time-based burst (forward only; re-arms on reverse).
        const contactAt = tl.labels.contact;
        let fired = false;
        tl.eventCallback("onUpdate", () => {
          const t = tl.time();
          if (!fired && t >= contactAt) {
            fired = true;
            if (point.current) fireContactBurst(point.current, stage.openingFlash.current);
          } else if (fired && t < contactAt - 0.15) {
            fired = false;
          }
        });
      });

      mm.add(REDUCED, () => {
        gsap.set([left.current, right.current], { x: 0 });
        gsap.set(root.current?.querySelector(".opening__quote") ?? [], { autoAlpha: 1 });
        gsap.set(root.current?.querySelector(".opening__title") ?? [], { autoAlpha: 0 });
        gsap.set(root.current?.querySelector(".contact-glow") ?? [], { autoAlpha: 0.6 });
      });

      return () => mm.revert();
    },
    { scope: root },
  );

  return (
    <section id="chapter-light" ref={root} className="opening" aria-labelledby="opening-title">
      <div ref={point} className="opening-hands contact-point">
        <Hand side="left" outerRef={left} />
        <Hand side="right" outerRef={right} />
        <FingertipContact />
      </div>

      <div className="opening__title" dir={content.dir}>
        <p className="label-caps text-turquoise">{c.kicker}</p>
        <h1
          id="opening-title"
          className="font-display mt-3 text-5xl leading-none font-light text-ivory md:text-7xl lg:text-8xl"
        >
          {c.title}
        </h1>
        <p className="font-display mt-4 text-lg text-muted-foreground italic md:text-xl">{c.subtitle}</p>
        <p className="label-caps mt-8 text-gold">{c.hint}</p>
        <div className="scroll-cue" aria-hidden="true" />
      </div>

      <div className="opening__quote" dir={content.dir}>
        <p className="font-display text-3xl font-light text-ivory md:text-5xl">{c.quoteA}</p>
        <p className="font-display mt-2 text-3xl text-gold-glow italic md:text-5xl">{c.quoteB}</p>
      </div>
    </section>
  );
}

import { createContext, useContext, useRef, type RefObject } from "react";

export interface StageRefs {
  opening: RefObject<HTMLDivElement | null>;
  openingFlash: RefObject<HTMLDivElement | null>;
  clouds: RefObject<HTMLDivElement | null>;
  cloudsInner: RefObject<HTMLDivElement | null>;
  village: RefObject<HTMLDivElement | null>;
  villageInner: RefObject<HTMLDivElement | null>;
  finale: RefObject<HTMLDivElement | null>;
}

const StageContext = createContext<StageRefs | null>(null);

export function useCreateStageRefs(): StageRefs {
  return {
    opening: useRef<HTMLDivElement>(null),
    openingFlash: useRef<HTMLDivElement>(null),
    clouds: useRef<HTMLDivElement>(null),
    cloudsInner: useRef<HTMLDivElement>(null),
    village: useRef<HTMLDivElement>(null),
    villageInner: useRef<HTMLDivElement>(null),
    finale: useRef<HTMLDivElement>(null),
  };
}

export const StageProvider = StageContext.Provider;

export function useStage(): StageRefs {
  const ctx = useContext(StageContext);
  if (!ctx) throw new Error("useStage must be used inside <StageProvider>");
  return ctx;
}

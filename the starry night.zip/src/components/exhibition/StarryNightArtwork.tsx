import type { CSSProperties, Ref } from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { ART, MOON, STARS } from "./art";
import { CoverArt } from "./CoverArt";

interface Props {
  frameRef?: Ref<HTMLDivElement>;
  flashRef?: Ref<HTMLDivElement>;
  priority?: boolean;
}

/** The framed Starry-Night painting floating in black, with a breathing moon and stars. */
export function StarryNightArtwork({ frameRef, flashRef, priority }: Props) {
  const isMobile = useIsMobile();
  return (
    <div ref={frameRef} className="painting-frame">
      <CoverArt
        src={ART.starry.src}
        width={ART.starry.w}
        height={ART.starry.h}
        focusX={isMobile ? 0.78 : 0.5}
        priority={priority}
        alt="A swirling starry night sky over a sleeping village, painted in thick blue and gold strokes"
      >
        <span className="moon-halo moon-halo--outer" style={{ left: `${MOON.x}%`, top: `${MOON.y}%` }} />
        <span className="moon-halo" style={{ left: `${MOON.x}%`, top: `${MOON.y}%` }} />
        {STARS.map(([x, y, d], i) => (
          <span
            key={i}
            className="star-glow"
            style={
              {
                left: `${x}%`,
                top: `${y}%`,
                "--d": `${d}s`,
                "--delay": `${-i * 1.37}s`,
              } as CSSProperties
            }
          />
        ))}
      </CoverArt>
      <div className="painting-frame__texture" />
      <div ref={flashRef} className="painting-frame__flash" />
    </div>
  );
}

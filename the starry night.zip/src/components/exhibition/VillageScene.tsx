import { useRef } from "react";
import type { SiteContent } from "@/content/site";
import { gsap, useGSAP, MOTION, REDUCED } from "@/lib/gsap";
import { ART } from "./art";
import { GlassInformationPanel } from "./GlassInformationPanel";
import { revealPanels } from "./reveal";
import { useStage } from "./StageContext";

const PREVIEWS = [
  { src: ART.village.src, pos: "18% 60%" },
  { src: ART.starry.src, pos: "55% 35%" },
  { src: ART.sky.src, pos: "70% 30%" },
];

/** Chapter 04 — the city that never sleeps: crossfade from clouds, living windows, the work. */
export function VillageScene({ content }: { content: SiteContent }) {
  const root = useRef<HTMLElement>(null);
  const stage = useStage();
  const c = content.village;

  useGSAP(
    () => {
      const mm = gsap.matchMedia();
      mm.add(MOTION, () => {
        // Cinematic crossfade: the sky dissolves while the village rises out of it.
        const xfade = { trigger: root.current, start: "top bottom", end: "top 10%", scrub: 1.6, invalidateOnRefresh: true };
        gsap.fromTo(stage.cloudsInner.current, { autoAlpha: 1, scale: 1 }, { autoAlpha: 0, scale: 1.14, filter: "blur(7px)", ease: "none", scrollTrigger: xfade });
        gsap.fromTo(stage.village.current, { autoAlpha: 0, scale: 1.16, filter: "blur(6px)" }, { autoAlpha: 1, scale: 1, filter: "blur(0px)", ease: "power1.out", scrollTrigger: xfade });
        const art = stage.villageInner.current?.querySelector(".cover-host");
        gsap.fromTo(art, { yPercent: 2, scale: 1.08 }, {
          yPercent: -3,
          scale: 1.08,
          ease: "none",
          scrollTrigger: { trigger: root.current, start: "top top", end: "bottom bottom", scrub: 1.8, invalidateOnRefresh: true },
        });
        if (root.current) revealPanels(root.current);
      });
      mm.add(REDUCED, () => {
        gsap.set(stage.village.current, { autoAlpha: 0 });
        gsap.to(stage.village.current, {
          autoAlpha: 1,
          duration: 0.6,
          scrollTrigger: { trigger: root.current, start: "top 60%", toggleActions: "play none none reverse" },
        });
      });
      return () => mm.revert();
    },
    { scope: root },
  );

  return (
    <section id="chapter-city" ref={root} className="scene" aria-labelledby="city-title" dir={content.dir}>
      <header className="scene__intro" data-intro>
        <p className="label-caps text-turquoise">{c.chapter}</p>
        <h2 id="city-title" className="font-display mt-4 text-5xl font-light text-ivory md:text-7xl">
          {c.title}
        </h2>
        <p className="font-display mx-auto mt-5 max-w-xl text-xl text-muted-foreground italic">{c.lede}</p>
      </header>

      <div className="panel-row" data-align="center">
        <GlassInformationPanel id="p-projects" wide {...c.projects}>
          <ul className="mt-8 grid gap-6 sm:grid-cols-3">
            {c.projects.items.map((p, i) => (
              <li key={i} data-reveal>
                <a href="#" className="group block" onClick={(e) => e.preventDefault()}>
                  <div className="art-thumb aspect-[4/5]">
                    <img src={PREVIEWS[i].src} alt="" loading="lazy" style={{ objectPosition: PREVIEWS[i].pos }} />
                  </div>
                  <p className="label-caps mt-4 text-gold/80">{p.meta}</p>
                  <p className="font-display mt-1 text-2xl text-ivory transition-colors group-hover:text-gold-glow">
                    {p.title}
                  </p>
                  <p className="mt-1 text-sm text-muted-foreground">{p.desc}</p>
                </a>
              </li>
            ))}
          </ul>
        </GlassInformationPanel>
      </div>

      <div className="panel-row" data-align="start">
        <GlassInformationPanel id="p-selected" {...c.selected}>
          <figure data-reveal className="mt-7">
            <div className="art-thumb aspect-[16/10]">
              <img src={ART.sky.src} alt="" loading="lazy" style={{ objectPosition: "62% 30%" }} />
            </div>
            <figcaption className="label-caps mt-3 text-muted-foreground">{c.selected.caption}</figcaption>
          </figure>
          <p data-reveal className="mt-6 leading-relaxed text-muted-foreground">{c.selected.body}</p>
        </GlassInformationPanel>
      </div>

      <div className="panel-row" data-align="end">
        <GlassInformationPanel id="p-achievements" {...c.achievements}>
          <ul className="mt-6 divide-y divide-border">
            {c.achievements.items.map((a, i) => (
              <li key={i} data-reveal className="flex items-baseline justify-between gap-6 py-4">
                <span className="font-display text-xl text-ivory">{a.title}</span>
                <span className="label-caps text-gold">{a.meta}</span>
              </li>
            ))}
          </ul>
        </GlassInformationPanel>
      </div>

      <div className="panel-row" data-align="start">
        <GlassInformationPanel id="p-experience" {...c.experience}>
          <ol className="relative mt-7 space-y-7 border-s border-gold/30 ps-6">
            {c.experience.items.map((x, i) => (
              <li key={i} data-reveal className="relative">
                <span
                  className="absolute -start-[1.95rem] top-2 size-2.5 rounded-full bg-gold shadow-[0_0_12px_var(--gold)]"
                  aria-hidden="true"
                />
                <p className="label-caps text-gold/80">{x.years}</p>
                <p className="font-display mt-1 text-xl text-ivory">{x.role}</p>
                <p className="text-sm text-muted-foreground">{x.note}</p>
              </li>
            ))}
          </ol>
        </GlassInformationPanel>
      </div>
    </section>
  );
}

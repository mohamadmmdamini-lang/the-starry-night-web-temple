import starryNight from "@/assets/starry-night.webp";
import skyClouds from "@/assets/sky-clouds.webp";
import cloudsMid from "@/assets/clouds-mid.webp";
import cloudsFront from "@/assets/clouds-front.webp";
import villageNight from "@/assets/village-night.webp";
import handLeft from "@/assets/hand-left.webp";
import handRight from "@/assets/hand-right.webp";

export const ART = {
  starry: { src: starryNight, w: 1600, h: 1072 },
  sky: { src: skyClouds, w: 1920, h: 1088 },
  cloudsMid: { src: cloudsMid, w: 1920, h: 1088 },
  cloudsFront: { src: cloudsFront, w: 1920, h: 1088 },
  village: { src: villageNight, w: 1920, h: 1088 },
} as const;

/** Fingertip anchors measured from the transparent hand cut-outs (fraction of image size). */
export const HANDS = {
  left: { src: handLeft, w: 1495, h: 416, tipX: 0.9993, tipY: 0.363 },
  right: { src: handRight, w: 1463, h: 502, tipX: 0, tipY: 0.4392 },
} as const;

/** Highlights in the opening painting (percent of the artwork). */
export const MOON = { x: 86.5, y: 16.5 };
export const STARS: ReadonlyArray<readonly [number, number, number]> = [
  [23.2, 17, 4.6],
  [58, 4.2, 5.2],
  [66, 22.4, 6.1],
  [32.6, 52.2, 3.8],
  [31.3, 31.2, 7.4],
  [10, 47, 5.6],
  [40.6, 4.2, 4.1],
  [2.6, 44, 6.6],
  [24, 2.5, 5],
];

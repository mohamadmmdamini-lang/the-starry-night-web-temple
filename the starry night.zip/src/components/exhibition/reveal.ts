import { gsap } from "@/lib/gsap";

/**
 * Scroll-linked reveals for exhibition panels.
 * The animation reverses naturally when the visitor scrolls upward.
 */
export function revealPanels(scope: Element) {
  scope.querySelectorAll<HTMLElement>(".glass-panel").forEach((panel) => {
    const lines = panel.querySelectorAll<HTMLElement>("[data-reveal]");
    const fromRight = panel.closest('[data-align="end"]') !== null;

    gsap.fromTo(
      panel,
      {
        y: 76,
        x: fromRight ? 22 : -22,
        autoAlpha: 0,
        scale: 0.975,
        filter: "blur(7px)",
        willChange: "transform, opacity, filter",
      },
      {
        y: 0,
        x: 0,
        autoAlpha: 1,
        scale: 1,
        filter: "blur(0px)",
        ease: "power2.out",
        scrollTrigger: {
          trigger: panel,
          start: "top 88%",
          end: "top 48%",
          scrub: 1.5,
          invalidateOnRefresh: true,
        },
      },
    );

    if (lines.length) {
      gsap.fromTo(
        lines,
        { y: 22, autoAlpha: 0, filter: "blur(5px)" },
        {
          y: 0,
          autoAlpha: 1,
          filter: "blur(0px)",
          stagger: 0.08,
          ease: "power2.out",
          scrollTrigger: {
            trigger: panel,
            start: "top 82%",
            end: "top 43%",
            scrub: 1.35,
            invalidateOnRefresh: true,
          },
        },
      );
    }
  });

  scope.querySelectorAll<HTMLElement>("[data-intro]").forEach((intro) => {
    gsap.fromTo(
      intro.children,
      { y: 36, autoAlpha: 0, filter: "blur(6px)" },
      {
        y: 0,
        autoAlpha: 1,
        filter: "blur(0px)",
        stagger: 0.1,
        ease: "power2.out",
        scrollTrigger: {
          trigger: intro,
          start: "top 88%",
          end: "top 52%",
          scrub: 1.4,
          invalidateOnRefresh: true,
        },
      },
    );
  });
}

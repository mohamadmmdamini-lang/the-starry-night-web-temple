/**
 * Editable portfolio content.
 * Everything here is PLACEHOLDER copy — replace it with your own words, links and handles.
 * Never ship invented achievements or experience.
 */

export type Lang = "en" | "fa";

/** Contact destinations shared by both languages. Replace with your real details. */
export const CONTACT_LINKS = {
  email: "hello@example.com",
  instagram: "yourhandle",
  linkedin: "yourhandle",
  telegram: "yourhandle",
} as const;

export const CONTACT_HREFS = [
  `mailto:${CONTACT_LINKS.email}`,
  `https://instagram.com/${CONTACT_LINKS.instagram}`,
  `https://www.linkedin.com/in/${CONTACT_LINKS.linkedin}`,
  `https://t.me/${CONTACT_LINKS.telegram}`,
  `mailto:${CONTACT_LINKS.email}?subject=${encodeURIComponent("Hello — let's create something")}`,
] as const;

export const CONTACT_VALUES = [
  CONTACT_LINKS.email,
  `@${CONTACT_LINKS.instagram}`,
  `in/${CONTACT_LINKS.linkedin}`,
  `@${CONTACT_LINKS.telegram}`,
  "→",
] as const;

export interface PanelCopy {
  index: string;
  label: string;
  heading: string;
  body: string;
}

export interface SiteContent {
  dir: "ltr" | "rtl";
  brand: string;
  langToggle: string;
  skipToContact: string;
  chapters: { id: string; numeral: string; name: string }[];
  opening: {
    kicker: string;
    title: string;
    subtitle: string;
    hint: string;
    quoteA: string;
    quoteB: string;
  };
  clouds: {
    chapter: string;
    title: string;
    lede: string;
    about: PanelCopy;
    story: PanelCopy;
    philosophy: PanelCopy & { quote: string };
    skills: PanelCopy & { items: { name: string; note: string }[] };
  };
  village: {
    chapter: string;
    title: string;
    lede: string;
    projects: PanelCopy & { items: { title: string; meta: string; desc: string }[] };
    selected: PanelCopy & { caption: string };
    achievements: PanelCopy & { items: { title: string; meta: string }[] };
    experience: PanelCopy & { items: { role: string; years: string; note: string }[] };
  };
  contact: {
    chapter: string;
    title: string;
    hint: string;
    labels: string[];
    footer: string;
  };
}

const en: SiteContent = {
  dir: "ltr",
  brand: "Your Name",
  langToggle: "فا",
  skipToContact: "Skip to contact",
  chapters: [
    { id: "chapter-light", numeral: "I", name: "The Creation of Light" },
    { id: "chapter-sky", numeral: "II", name: "The Breathing Sky" },
    { id: "chapter-city", numeral: "III", name: "The City That Never Sleeps" },
    { id: "chapter-connection", numeral: "IV", name: "The Final Connection" },
  ],
  opening: {
    kicker: "An interactive exhibition",
    title: "The Living Masterpiece",
    subtitle: "A portfolio painted in light",
    hint: "Scroll to enter",
    quoteA: "Art is not something you look at.",
    quoteB: "It is something you enter.",
  },
  clouds: {
    chapter: "Chapter II",
    title: "The Breathing Sky",
    lede: "Drift with the wind. Meet the hand behind the brush.",
    about: {
      index: "01",
      label: "About me",
      heading: "A few words about who I am",
      body: "Replace this text with a short introduction — who you are, what you create, and what moves you to make it. Two or three sentences are enough.",
    },
    story: {
      index: "02",
      label: "My story",
      heading: "Where it all began",
      body: "Tell your story here: the first moment art caught you, the path you followed, and where you stand today. Keep it personal and honest.",
    },
    philosophy: {
      index: "03",
      label: "My philosophy",
      heading: "What I believe about the work",
      body: "Describe the principles that guide your practice — how you begin, what you refuse to compromise on, and what you hope people feel.",
      quote: "Write your guiding principle here.",
    },
    skills: {
      index: "04",
      label: "My skills",
      heading: "Tools of the craft",
      body: "List the disciplines, media and tools you work with.",
      items: [
        { name: "Skill name", note: "One line about how you use it" },
        { name: "Skill name", note: "One line about how you use it" },
        { name: "Skill name", note: "One line about how you use it" },
        { name: "Skill name", note: "One line about how you use it" },
      ],
    },
  },
  village: {
    chapter: "Chapter III",
    title: "The City That Never Sleeps",
    lede: "Every lit window holds a piece of work.",
    projects: {
      index: "05",
      label: "My projects",
      heading: "Works in progress, works complete",
      body: "",
      items: [
        { title: "Project title", meta: "Year · Medium", desc: "A short description of this project." },
        { title: "Project title", meta: "Year · Medium", desc: "A short description of this project." },
        { title: "Project title", meta: "Year · Medium", desc: "A short description of this project." },
      ],
    },
    selected: {
      index: "06",
      label: "Selected work",
      heading: "A featured piece",
      body: "Write about the work you are proudest of — what it is, how it was made, and why it matters to you.",
      caption: "Title of the work — Year, medium, dimensions",
    },
    achievements: {
      index: "07",
      label: "My achievements",
      heading: "Moments worth remembering",
      body: "",
      items: [
        { title: "Award or recognition", meta: "Year" },
        { title: "Exhibition or publication", meta: "Year" },
        { title: "Milestone", meta: "Year" },
      ],
    },
    experience: {
      index: "08",
      label: "My experience",
      heading: "The road so far",
      body: "",
      items: [
        { role: "Role · Organisation", years: "Start — End", note: "One line about what you did there." },
        { role: "Role · Organisation", years: "Start — End", note: "One line about what you did there." },
        { role: "Role · Organisation", years: "Start — End", note: "One line about what you did there." },
      ],
    },
  },
  contact: {
    chapter: "Chapter IV",
    title: "The Final Connection",
    hint: "Touch a title to connect",
    labels: ["Email", "Instagram", "LinkedIn", "Telegram", "Get in touch"],
    footer: "© Your Name — The Living Masterpiece",
  },
};

const fa: SiteContent = {
  dir: "rtl",
  brand: "نام شما",
  langToggle: "EN",
  skipToContact: "رفتن به بخش تماس",
  chapters: [
    { id: "chapter-light", numeral: "I", name: "آفرینش نور" },
    { id: "chapter-sky", numeral: "II", name: "آسمانِ نفس‌کشنده" },
    { id: "chapter-city", numeral: "III", name: "شهری که هرگز نمی‌خوابد" },
    { id: "chapter-connection", numeral: "IV", name: "پیوند پایانی" },
  ],
  opening: {
    kicker: "یک نمایشگاه تعاملی",
    title: "شاهکارِ زنده",
    subtitle: "پورتفولیویی که با نور نقاشی شده است",
    hint: "برای ورود اسکرول کنید",
    quoteA: "هنر چیزی نیست که به آن نگاه کنی.",
    quoteB: "چیزی است که واردش می‌شوی.",
  },
  clouds: {
    chapter: "فصل دوم",
    title: "آسمانِ نفس‌کشنده",
    lede: "با باد همراه شوید و دستی را که قلم‌مو را می‌گیرد بشناسید.",
    about: {
      index: "۰۱",
      label: "درباره من",
      heading: "چند کلمه درباره‌ی اینکه چه کسی هستم",
      body: "این متن را با معرفی کوتاهی از خودتان جایگزین کنید — اینکه چه کسی هستید، چه می‌سازید و چه چیزی شما را به ساختن وامی‌دارد. دو یا سه جمله کافی است.",
    },
    story: {
      index: "۰۲",
      label: "داستان من",
      heading: "از کجا شروع شد",
      body: "داستان خود را اینجا بنویسید: اولین لحظه‌ای که هنر شما را به خود جذب کرد، مسیری که پیمودید و جایی که امروز ایستاده‌اید.",
    },
    philosophy: {
      index: "۰۳",
      label: "فلسفه من",
      heading: "آنچه درباره‌ی کار باور دارم",
      body: "اصولی را که کار شما را هدایت می‌کنند شرح دهید — چگونه آغاز می‌کنید، بر سر چه چیزی کوتاه نمی‌آیید و امیدوارید مخاطب چه احساسی داشته باشد.",
      quote: "اصل راهنمای خود را اینجا بنویسید.",
    },
    skills: {
      index: "۰۴",
      label: "مهارت‌های من",
      heading: "ابزارهای این هنر",
      body: "رشته‌ها، رسانه‌ها و ابزارهایی را که با آن‌ها کار می‌کنید فهرست کنید.",
      items: [
        { name: "نام مهارت", note: "یک خط درباره‌ی نحوه‌ی استفاده‌ی شما" },
        { name: "نام مهارت", note: "یک خط درباره‌ی نحوه‌ی استفاده‌ی شما" },
        { name: "نام مهارت", note: "یک خط درباره‌ی نحوه‌ی استفاده‌ی شما" },
        { name: "نام مهارت", note: "یک خط درباره‌ی نحوه‌ی استفاده‌ی شما" },
      ],
    },
  },
  village: {
    chapter: "فصل سوم",
    title: "شهری که هرگز نمی‌خوابد",
    lede: "پشت هر پنجره‌ی روشن، اثری نشسته است.",
    projects: {
      index: "۰۵",
      label: "پروژه‌های من",
      heading: "کارهای در جریان و به پایان رسیده",
      body: "",
      items: [
        { title: "عنوان پروژه", meta: "سال · رسانه", desc: "توضیحی کوتاه درباره‌ی این پروژه." },
        { title: "عنوان پروژه", meta: "سال · رسانه", desc: "توضیحی کوتاه درباره‌ی این پروژه." },
        { title: "عنوان پروژه", meta: "سال · رسانه", desc: "توضیحی کوتاه درباره‌ی این پروژه." },
      ],
    },
    selected: {
      index: "۰۶",
      label: "آثار منتخب",
      heading: "یک اثر ویژه",
      body: "درباره‌ی اثری که بیش از همه به آن افتخار می‌کنید بنویسید — چیست، چگونه ساخته شد و چرا برایتان مهم است.",
      caption: "عنوان اثر — سال، رسانه، ابعاد",
    },
    achievements: {
      index: "۰۷",
      label: "دستاوردهای من",
      heading: "لحظه‌هایی که ارزش به خاطر سپردن دارند",
      body: "",
      items: [
        { title: "عنوان جایزه یا افتخار", meta: "سال" },
        { title: "نمایشگاه یا انتشار", meta: "سال" },
        { title: "نقطه‌ی عطف", meta: "سال" },
      ],
    },
    experience: {
      index: "۰۸",
      label: "تجربه‌های من",
      heading: "مسیری که تا امروز پیموده‌ام",
      body: "",
      items: [
        { role: "سمت · سازمان", years: "شروع — پایان", note: "یک خط درباره‌ی کاری که آنجا انجام دادید." },
        { role: "سمت · سازمان", years: "شروع — پایان", note: "یک خط درباره‌ی کاری که آنجا انجام دادید." },
        { role: "سمت · سازمان", years: "شروع — پایان", note: "یک خط درباره‌ی کاری که آنجا انجام دادید." },
      ],
    },
  },
  contact: {
    chapter: "فصل چهارم",
    title: "پیوند پایانی",
    hint: "برای برقراری ارتباط، یک عنوان را لمس کنید",
    labels: ["ایمیل", "اینستاگرام", "لینکدین", "تلگرام", "در تماس باشید"],
    footer: "© نام شما — شاهکارِ زنده",
  },
};

export const CONTENT: Record<Lang, SiteContent> = { en, fa };

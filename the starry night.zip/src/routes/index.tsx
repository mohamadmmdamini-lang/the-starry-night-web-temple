import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { CONTENT, CONTACT_HREFS, type Lang } from "@/content/site";
import { StageProvider, useCreateStageRefs } from "@/components/exhibition/StageContext";
import { ExhibitionStage } from "@/components/exhibition/ExhibitionStage";
import { OpeningScene } from "@/components/exhibition/OpeningScene";
import { CloudScene } from "@/components/exhibition/CloudScene";
import { VillageScene } from "@/components/exhibition/VillageScene";

export const Route = createFileRoute("/")({
  component: Index,
});

function Index() {
  const [lang, setLang] = useState<Lang>("en");
  const content = CONTENT[lang];
  const stage = useCreateStageRefs();

  return (
    <StageProvider value={stage}>
      <div className="exhibition" dir={content.dir}>
        <ExhibitionStage />

        <header className="fixed inset-x-0 top-0 z-50 flex items-center justify-between px-6 py-5 md:px-12">
          <a href="#chapter-light" className="font-display text-lg text-ivory">
            {content.brand}
          </a>
          <nav className="flex items-center gap-5">
            <a href="#chapter-connection" className="text-sm text-ivory transition-opacity hover:opacity-70">
              {content.skipToContact}
            </a>
            <button
              type="button"
              onClick={() => setLang((current) => (current === "en" ? "fa" : "en"))}
              className="rounded-full border border-white/20 px-4 py-2 text-sm text-ivory transition-colors hover:bg-white/10"
              aria-label="Change language"
            >
              {content.langToggle}
            </button>
          </nav>
        </header>

        <main className="content">
          <OpeningScene content={content} />
          <CloudScene content={content} />
          <VillageScene content={content} />

          <section
            id="chapter-connection"
            className="scene"
            aria-labelledby="contact-title"
            dir={content.dir}
          >
            <header className="scene__intro" data-intro>
              <p className="label-caps text-turquoise">{content.contact.chapter}</p>
              <h2
                id="contact-title"
                className="font-display mt-5 text-5xl font-light text-ivory md:text-7xl"
              >
                {content.contact.title}
              </h2>
              <p className="mx-auto mt-5 max-w-xl text-muted-foreground">
                {content.contact.hint}
              </p>
            </header>

            <div className="mx-auto flex max-w-3xl flex-wrap justify-center gap-4 px-6 pb-24">
              {content.contact.labels.map((label, index) => (
                <a
                  key={`${label}-${index}`}
                  href={CONTACT_HREFS[index]}
                  className="rounded-2xl border border-white/15 bg-white/5 px-7 py-5 text-ivory backdrop-blur-xl transition duration-300 hover:-translate-y-1 hover:border-amber-300/50 hover:bg-white/10"
                >
                  {label}
                </a>
              ))}
            </div>

            <footer className="pb-10 text-center text-sm text-muted-foreground">
              {content.contact.footer}
            </footer>
          </section>
        </main>
      </div>
    </StageProvider>
  );
}
